IconReaper - первый тестовый набор

КАК СОБРАТЬ ЧЕРЕЗ GITHUB:
1. Создай новый репозиторий на GitHub.
2. Загрузи в него файлы: Makefile, control, IconReaper.plist, Tweak.xm
3. Создай файл по пути .github/workflows/build.yml
   (на сайте: Add file -> Create new file, в имени напиши
   .github/workflows/build.yml, вставь содержимое из файла build.yml).
4. Открой вкладку Actions, дождись зелёной галочки.
5. Внутри запуска скачай Artifact "IconReaper-deb" (внутри будет .deb).
6. Закинь .deb на iPhone, открой через Filza, нажми Install, потом Respring.

ПРОВЕРКА:
- Удали любое ненужное приложение (зажать иконку -> крестик -> Удалить).
- Если эффекта нет, открой в Filza файл /var/mobile/iconreaper.log
  и пришли мне его содержимое.

Эти файлы не собирались и не запускались, их надо проверить первым запуском.
